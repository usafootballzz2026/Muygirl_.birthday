import React, { useMemo } from 'react';

interface AmbientParticlesProps {
  variant?: 'welcome' | 'ambient' | 'login';
  burstKey?: number;
}

const PETAL_COLORS = ['#FBCFE8', '#F9A8D4', '#E9D5FF', '#F472B6', '#DDD6FE'];

export const AmbientParticles: React.FC<AmbientParticlesProps> = ({
  variant = 'ambient',
  burstKey = 0,
}) => {
  const hearts = useMemo(() => {
    const count = variant === 'ambient' ? 8 : 14;
    return Array.from({ length: count }, (_, i) => ({
      id: i,
      left: `${(i * 19 + 7) % 94}%`,
      top: `${(i * 23 + 11) % 86}%`,
      size: 14 + (i % 4) * 5,
      delay: `${(i * 0.65) % 4}s`,
      duration: `${5 + (i % 4) * 1.4}s`,
      opacity: variant === 'ambient' ? 0.22 : 0.36,
      color: i % 2 === 0 ? '#EC4899' : '#A855F7',
    }));
  }, [variant]);

  const stars = useMemo(() => {
    if (variant !== 'login') return [];
    return Array.from({ length: 14 }, (_, i) => ({
      id: i,
      left: `${(i * 29 + 5) % 95}%`,
      top: `${(i * 17 + 6) % 90}%`,
      size: 12 + (i % 3) * 5,
      delay: `${(i * 0.45) % 3}s`,
    }));
  }, [variant]);

  const petals = useMemo(() => {
    const count = variant === 'ambient' ? 7 : 12;
    return Array.from({ length: count }, (_, i) => ({
      id: i,
      left: `${(i * 17 + 4) % 96}%`,
      delay: `${(i * 1.1) % 7}s`,
      duration: `${9 + (i % 5) * 2}s`,
      size: 10 + (i % 3) * 4,
      color: PETAL_COLORS[i % PETAL_COLORS.length],
    }));
  }, [variant]);

  const burstHearts = useMemo(() => {
    if (!burstKey) return [];
    return Array.from({ length: 18 }, (_, i) => ({
      id: `${burstKey}-${i}`,
      left: `${10 + ((i * 47) % 80)}%`,
      delay: `${(i % 6) * 0.12}s`,
      size: 16 + (i % 4) * 6,
      color: i % 2 === 0 ? '#EC4899' : '#9333EA',
    }));
  }, [burstKey]);

  return (
    <div
      className="pointer-events-none fixed inset-0 overflow-hidden z-0 select-none"
      aria-hidden="true"
    >
      {/* Soft glowing radial washes */}
      <div className="absolute -top-28 -left-24 w-96 h-96 rounded-full bg-pink-200/35 blur-3xl" />
      <div className="absolute top-1/3 -right-28 w-[28rem] h-[28rem] rounded-full bg-purple-200/35 blur-3xl" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 rounded-full bg-fuchsia-100/40 blur-3xl" />

      {/* Glowing twinkling stars for Secret Login Page */}
      {stars.map((s) => (
        <div
          key={`star-${s.id}`}
          className="absolute animate-pulse"
          style={{
            left: s.left,
            top: s.top,
            animationDelay: s.delay,
          }}
        >
          <svg width={s.size} height={s.size} viewBox="0 0 24 24" fill="#FDE047">
            <path d="M12 2L14.4 9.2L22 12L14.4 14.8L12 22L9.6 14.8L2 12L9.6 9.2L12 2Z" />
          </svg>
        </div>
      ))}

      {/* Floating gentle hearts */}
      {hearts.map((h) => (
        <div
          key={h.id}
          className="absolute animate-float-slow"
          style={{
            left: h.left,
            top: h.top,
            animationDelay: h.delay,
            animationDuration: h.duration,
            opacity: h.opacity,
          }}
        >
          <svg
            width={h.size}
            height={h.size}
            viewBox="0 0 24 24"
            fill={h.color}
          >
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
          </svg>
        </div>
      ))}

      {/* Falling soft pink & lavender flower petals */}
      {petals.map((p) => (
        <div
          key={`petal-${p.id}`}
          className="absolute -top-8"
          style={{
            left: p.left,
            animation: `petalFall ${p.duration} linear ${p.delay} infinite`,
          }}
        >
          <svg width={p.size} height={p.size * 1.3} viewBox="0 0 20 26" fill="none">
            <path
              d="M10 1C15 5 19 11 17 18C15 23 11 25 10 25C9 25 5 23 3 18C1 11 5 5 10 1Z"
              fill={p.color}
              fillOpacity="0.8"
            />
          </svg>
        </div>
      ))}

      {/* Celebration burst hearts */}
      {burstHearts.map((bh) => (
        <div
          key={bh.id}
          className="absolute -top-8"
          style={{
            left: bh.left,
            animation: `petalFall 3.8s ease-in ${bh.delay} 1 forwards`,
          }}
        >
          <svg width={bh.size} height={bh.size} viewBox="0 0 24 24" fill={bh.color}>
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
          </svg>
        </div>
      ))}
    </div>
  );
};
