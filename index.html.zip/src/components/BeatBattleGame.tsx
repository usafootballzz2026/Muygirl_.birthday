import React, { useCallback, useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Volume2,
  VolumeX,
  RotateCcw,
  Trophy,
  Crown,
  Heart,
  Star,
  Music,
  Play,
} from 'lucide-react';
import {
  playBeatTapSound,
  playFunnyBoingSound,
  playTurnSwapSound,
  playVictoryFanfareSound,
} from '../utils/soundFx';

type GameState = 'INTRO' | 'PLAYING' | 'FINISHED';
type GameMode = 'two-player' | 'vs-bot';
type PlayerTurn = 1 | 2;
type CharacterMood = 'dancing' | 'winning' | 'losing' | 'idle';

interface FloatingBurst {
  id: number;
  x: number;
  y: number;
  label: string;
  kind: 'heart' | 'star';
  player: PlayerTurn;
}

const GAME_DURATION_SECONDS = 30;
const TURN_LENGTH_SECONDS = 5;

const FUNNY_P1_REACTIONS = ['BOOM! 😂', 'SLAY! 🔥', 'TOO FAST!', 'BEAT BOSS!', 'OMG ❤️'];
const FUNNY_P2_REACTIONS = ['QUEEN! 👑', 'SLAY SIS!', 'YASSS! ⭐', 'BIRTHDAY POWER!', 'HAHA! 😂'];

interface SisterCharacterProps {
  player: PlayerTurn;
  mood: CharacterMood;
  isActiveTurn: boolean;
  tapPulseKey: number;
}

const SisterCharacter: React.FC<SisterCharacterProps> = ({
  player,
  mood,
  isActiveTurn,
  tapPulseKey,
}) => {
  const isP2 = player === 2;
  const hairColor = '#2A1830';
  const skinColor = '#F7C9A9';
  const dressPrimary = isP2 ? '#EC4899' : '#9333EA';
  const dressAccent = isP2 ? '#FBCFE8' : '#E9D5FF';

  return (
    <motion.div
      key={tapPulseKey}
      animate={
        mood === 'dancing' || isActiveTurn
          ? { y: [0, -8, 0], rotate: [-2, 2, -2] }
          : mood === 'winning'
          ? { y: [0, -10, 0], scale: [1, 1.05, 1] }
          : mood === 'losing'
          ? { x: [-2, 2, -2, 0] }
          : { y: 0 }
      }
      transition={{
        duration: mood === 'dancing' ? 0.55 : 0.8,
        repeat: Infinity,
        ease: 'easeInOut',
      }}
      className="relative flex flex-col items-center select-none"
    >
      {/* Funny status bubble when winning or losing */}
      {mood === 'losing' && (
        <span className="mb-1 text-xs font-semibold text-rose-600 whitespace-nowrap">
          Hmph! Not fair! 😤
        </span>
      )}
      {mood === 'winning' && (
        <span className="mb-1 text-xs font-semibold text-purple-700 whitespace-nowrap">
          {isP2 ? 'Queen Energy! 👑' : 'Haha Winning! 😎'}
        </span>
      )}

      <svg
        viewBox="0 0 120 140"
        fill="none"
        className="w-24 h-28 drop-shadow-sm"
        aria-label={isP2 ? 'Birthday Girl character' : 'Sister Player 1 character'}
      >
        {/* Golden crown for Birthday Girl (Player 2) */}
        {isP2 && (
          <g transform="translate(38, 4)">
            <path
              d="M4 22 L10 6 L22 15 L34 6 L40 22 Z"
              fill="#FBBF24"
              stroke="#D97706"
              strokeWidth="2"
              strokeLinejoin="round"
            />
            <circle cx="10" cy="6" r="2.5" fill="#EC4899" />
            <circle cx="22" cy="4" r="3" fill="#9333EA" />
            <circle cx="34" cy="6" r="2.5" fill="#EC4899" />
          </g>
        )}

        {/* Hair back / cute bun */}
        <circle cx="60" cy="40" r="28" fill={hairColor} />
        {!isP2 && <circle cx="60" cy="14" r="11" fill={hairColor} />}
        {isP2 && (
          <>
            <circle cx="34" cy="46" r="10" fill={hairColor} />
            <circle cx="86" cy="46" r="10" fill={hairColor} />
          </>
        )}

        {/* Festive outfit / dress */}
        <path
          d="M36 74 C36 66, 84 66, 84 74 L94 126 C94 130, 26 130, 26 126 Z"
          fill={dressPrimary}
        />
        <path d="M46 72 L60 88 L74 72 Z" fill={dressAccent} />

        {/* Waving arms */}
        <motion.path
          d="M37 78 Q18 68 20 54"
          stroke={skinColor}
          strokeWidth="9"
          strokeLinecap="round"
          animate={
            isActiveTurn || mood === 'winning'
              ? { d: ['M37 78 Q18 68 20 54', 'M37 78 Q14 54 24 44', 'M37 78 Q18 68 20 54'] }
              : {}
          }
          transition={{ duration: 0.45, repeat: Infinity }}
        />
        <motion.path
          d="M83 78 Q102 68 100 54"
          stroke={skinColor}
          strokeWidth="9"
          strokeLinecap="round"
          animate={
            isActiveTurn || mood === 'winning'
              ? { d: ['M83 78 Q102 68 100 54', 'M83 78 Q106 54 96 44', 'M83 78 Q102 68 100 54'] }
              : {}
          }
          transition={{ duration: 0.45, repeat: Infinity, delay: 0.2 }}
        />

        {/* Head */}
        <circle cx="60" cy="46" r="22" fill={skinColor} />
        {/* Hair bangs */}
        <path
          d="M38 42 C42 25, 78 25, 82 42 C74 32, 46 32, 38 42 Z"
          fill={hairColor}
        />

        {/* Rosy cheeks */}
        <circle cx="46" cy="51" r="4" fill="#FB7185" fillOpacity="0.45" />
        <circle cx="74" cy="51" r="4" fill="#FB7185" fillOpacity="0.45" />

        {/* Facial Expressions */}
        {mood === 'losing' ? (
          <>
            {/* Cute angry furrowed eyebrows */}
            <path d="M45 38 L54 42" stroke="#2B1537" strokeWidth="2.5" strokeLinecap="round" />
            <path d="M75 38 L66 42" stroke="#2B1537" strokeWidth="2.5" strokeLinecap="round" />
            <circle cx="50" cy="45" r="3" fill="#2B1537" />
            <circle cx="70" cy="45" r="3" fill="#2B1537" />
            {/* Cute pout mouth */}
            <path
              d="M54 57 Q60 52 66 57"
              stroke="#2B1537"
              strokeWidth="2.5"
              strokeLinecap="round"
              fill="none"
            />
            {/* Comic sweat drop */}
            <path
              d="M84 30 C87 35, 87 39, 84 40 C81 39, 81 35, 84 30 Z"
              fill="#60A5FA"
            />
          </>
        ) : mood === 'winning' ? (
          <>
            {/* Joyful laughing crescent eyes + giant happy grin */}
            <path d="M45 45 Q50 40 55 45" stroke="#2B1537" strokeWidth="2.6" strokeLinecap="round" fill="none" />
            <path d="M65 45 Q70 40 75 45" stroke="#2B1537" strokeWidth="2.6" strokeLinecap="round" fill="none" />
            <path
              d="M50 53 Q60 63 70 53 Z"
              fill="#E11D48"
              stroke="#2B1537"
              strokeWidth="2"
              strokeLinejoin="round"
            />
          </>
        ) : (
          <>
            {/* Bright sparkling eyes */}
            <circle cx="50" cy="45" r="3.2" fill="#2B1537" />
            <circle cx="70" cy="45" r="3.2" fill="#2B1537" />
            <circle cx="51" cy="43.8" r="1.1" fill="#FFFFFF" />
            <circle cx="71" cy="43.8" r="1.1" fill="#FFFFFF" />
            {/* Cute happy smile */}
            <path
              d="M52 54 Q60 61 68 54"
              stroke="#2B1537"
              strokeWidth="2.5"
              strokeLinecap="round"
              fill="none"
            />
          </>
        )}
      </svg>
    </motion.div>
  );
};

export const BeatBattleGame: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>('INTRO');
  const [gameMode, setGameMode] = useState<GameMode>('two-player');
  const [muted, setMuted] = useState(false);

  const [timeLeft, setTimeLeft] = useState(GAME_DURATION_SECONDS);
  const [activeTurn, setActiveTurn] = useState<PlayerTurn>(1);
  const [p1Score, setP1Score] = useState(0);
  const [p2Score, setP2Score] = useState(0);
  const [p1Pulse, setP1Pulse] = useState(0);
  const [p2Pulse, setP2Pulse] = useState(0);
  const [bursts, setBursts] = useState<FloatingBurst[]>([]);
  const [turnBannerText, setTurnBannerText] = useState("Me (Sister)'s Turn!");
  const [beatScale, setBeatScale] = useState(1);

  const burstIdRef = useRef(0);
  const p1ScoreRef = useRef(0);
  const p2ScoreRef = useRef(0);

  useEffect(() => {
    p1ScoreRef.current = p1Score;
    p2ScoreRef.current = p2Score;
  }, [p1Score, p2Score]);

  const spawnBurst = useCallback((player: PlayerTurn, text?: string) => {
    const id = ++burstIdRef.current;
    const pool = player === 1 ? FUNNY_P1_REACTIONS : FUNNY_P2_REACTIONS;
    const label = text || pool[id % pool.length];
    const burst: FloatingBurst = {
      id,
      x: 25 + ((id * 37) % 50),
      y: 25 + ((id * 19) % 35),
      label,
      kind: id % 2 === 0 ? 'heart' : 'star',
      player,
    };
    setBursts((prev) => [...prev.slice(-10), burst]);
    window.setTimeout(() => {
      setBursts((prev) => prev.filter((b) => b.id !== id));
    }, 750);
  }, []);

  const handleBeatTap = useCallback(
    (source: 'human' | 'bot' = 'human') => {
      if (gameState !== 'PLAYING') return;
      if (source === 'human' && gameMode === 'vs-bot' && activeTurn === 2) {
        return;
      }

      if (activeTurn === 1) {
        const next = p1ScoreRef.current + 1;
        setP1Score(next);
        setP1Pulse((k) => k + 1);
        playBeatTapSound(next, false, muted);
        spawnBurst(1);
      } else {
        const next = p2ScoreRef.current + 1;
        setP2Score(next);
        setP2Pulse((k) => k + 1);
        playBeatTapSound(next, true, muted);
        spawnBurst(2);
      }

      setBeatScale(0.92);
      window.setTimeout(() => setBeatScale(1), 90);
    },
    [activeTurn, gameMode, gameState, muted, spawnBurst]
  );

  // Main 30-second countdown & 5-second turn rotation loop
  useEffect(() => {
    if (gameState !== 'PLAYING') return;

    const interval = window.setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          window.clearInterval(interval);
          setGameState('FINISHED');
          playVictoryFanfareSound(muted);
          return 0;
        }
        const nextTime = prev - 1;
        const elapsed = GAME_DURATION_SECONDS - nextTime;
        const roundIdx = Math.floor(elapsed / TURN_LENGTH_SECONDS);
        const nextTurn: PlayerTurn = roundIdx % 2 === 0 ? 1 : 2;

        setActiveTurn((currTurn) => {
          if (currTurn !== nextTurn) {
            playTurnSwapSound(muted);
            setTurnBannerText(
              nextTurn === 1
                ? "Me (Sister)'s Turn! Tap Fast!"
                : "Birthday Girl's Turn! Go Queen! 👑"
            );
            if (
              (nextTurn === 1 && p1ScoreRef.current < p2ScoreRef.current) ||
              (nextTurn === 2 && p2ScoreRef.current < p1ScoreRef.current)
            ) {
              playFunnyBoingSound(muted);
            }
          }
          return nextTurn;
        });

        return nextTime;
      });
    }, 1000);

    return () => window.clearInterval(interval);
  }, [gameState, muted]);

  // Bot turn taps when playing Solo vs Sister Bot
  useEffect(() => {
    if (gameState !== 'PLAYING' || gameMode !== 'vs-bot' || activeTurn !== 2) {
      return;
    }

    const botTimer = window.setInterval(() => {
      handleBeatTap('bot');
    }, 220);

    return () => window.clearInterval(botTimer);
  }, [activeTurn, gameMode, gameState, handleBeatTap]);

  // Desktop keyboard support (Space / Enter) during active gameplay
  useEffect(() => {
    if (gameState !== 'PLAYING') return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'Enter') {
        const tag = (e.target as HTMLElement)?.tagName;
        if (tag === 'BUTTON' || tag === 'INPUT') return;
        e.preventDefault();
        handleBeatTap('human');
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [gameState, handleBeatTap]);

  const startGame = () => {
    setTimeLeft(GAME_DURATION_SECONDS);
    setActiveTurn(1);
    setP1Score(0);
    setP2Score(0);
    setBursts([]);
    setTurnBannerText("Me (Sister)'s Turn! Tap Fast!");
    setGameState('PLAYING');
    playTurnSwapSound(muted);
  };

  const getMood = (player: PlayerTurn): CharacterMood => {
    if (gameState === 'INTRO') return 'dancing';
    if (gameState === 'FINISHED') {
      if (p1Score > p2Score) return player === 1 ? 'winning' : 'losing';
      return player === 2 ? 'winning' : 'losing';
    }
    if (activeTurn === player) return 'dancing';
    if (player === 1 && p1Score < p2Score) return 'losing';
    if (player === 2 && p2Score < p1Score) return 'losing';
    return 'idle';
  };

  const secondsIntoTurn =
    (GAME_DURATION_SECONDS - timeLeft) % TURN_LENGTH_SECONDS;
  const turnCountdown = TURN_LENGTH_SECONDS - secondsIntoTurn;

  const p1Won = p1Score > p2Score;

  return (
    <section id="beat-battle" className="relative z-10 py-10 px-4">
      <div className="text-center mb-6">
        <p className="text-xs font-medium text-purple-700 mb-1.5">
          Chapter 04 · Arcade Mini-Game
        </p>
        <h2 className="font-cursive text-4xl text-[#2B1537] [text-wrap:balance]">
          SISTER vs SISTER – BEAT BATTLE 😂❤️
        </h2>
      </div>

      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-white via-pink-50/70 to-purple-100/70 border border-pink-200 shadow-[0_20px_50px_-16px_rgba(147,51,234,0.24)] p-4">
        {/* Top Arcade HUD Bar */}
        <div className="flex items-center justify-between gap-2 pb-4 border-b border-pink-200/70">
          <div className="flex items-center gap-2 min-w-0">
            <Music className="w-4 h-4 text-pink-600 shrink-0" />
            <span className="text-xs font-semibold text-[#2B1537] truncate">
              30s Beat Battle
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {gameState === 'PLAYING' && (
              <div className="px-3 py-1.5 rounded-xl bg-[#2B1537] text-white font-mono-tabular text-xs font-bold">
                {timeLeft}s Left
              </div>
            )}

            <button
              type="button"
              onClick={() => setMuted((m) => !m)}
              aria-label={muted ? 'Unmute game sounds' : 'Mute game sounds'}
              className="min-h-[40px] inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-purple-200 text-purple-800 active:bg-purple-50 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap"
            >
              {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              <span>{muted ? 'Muted' : 'Sound'}</span>
            </button>
          </div>
        </div>

        {/* INTRO SCREEN */}
        {gameState === 'INTRO' && (
          <div className="py-5 text-center space-y-6">
            <div className="grid grid-cols-2 gap-3 items-stretch">
              <div className="bg-white/90 border border-purple-200 rounded-2xl p-3 flex flex-col items-center">
                <SisterCharacter
                  player={1}
                  mood="dancing"
                  isActiveTurn={false}
                  tapPulseKey={0}
                />
                <p className="mt-1.5 font-semibold text-xs text-purple-900">
                  Player 1: Me
                </p>
                <p className="text-[11px] text-purple-700/80">Challenger</p>
              </div>

              <div className="bg-white/90 border border-pink-200 rounded-2xl p-3 flex flex-col items-center">
                <SisterCharacter
                  player={2}
                  mood="dancing"
                  isActiveTurn={false}
                  tapPulseKey={0}
                />
                <p className="mt-1.5 font-semibold text-xs text-pink-700">
                  My Sister 👑
                </p>
                <p className="text-[11px] text-pink-600/80">Birthday Girl</p>
              </div>
            </div>

            <div className="space-y-4">
              <p className="text-sm text-[#4B2D5C] leading-relaxed">
                Take turns tapping the <strong className="text-pink-600">BEAT</strong> button every 5 seconds in a 30-second sister rhythm showdown!
              </p>

              {/* Mobile-safe 2-option Mode Switch */}
              <div className="grid grid-cols-2 gap-1 p-1 bg-purple-100/80 rounded-2xl border border-purple-200">
                <button
                  type="button"
                  onClick={() => setGameMode('two-player')}
                  className={`min-h-[44px] px-2 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                    gameMode === 'two-player'
                      ? 'bg-white text-[#2B1537] shadow-sm'
                      : 'text-purple-800'
                  }`}
                >
                  2 Sisters
                </button>
                <button
                  type="button"
                  onClick={() => setGameMode('vs-bot')}
                  className={`min-h-[44px] px-2 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                    gameMode === 'vs-bot'
                      ? 'bg-white text-[#2B1537] shadow-sm'
                      : 'text-purple-800'
                  }`}
                >
                  Vs Sister Bot
                </button>
              </div>
            </div>

            <motion.button
              type="button"
              onClick={startGame}
              whileTap={{ scale: 0.97 }}
              className="w-full min-h-[52px] inline-flex items-center justify-center gap-2.5 px-6 py-4 rounded-2xl bg-gradient-to-r from-pink-500 via-fuchsia-500 to-purple-600 text-white font-bold text-base shadow-[0_14px_30px_-8px_rgba(236,72,153,0.55)] cursor-pointer"
            >
              <Play className="w-5 h-5 fill-white" />
              <span>START GAME</span>
            </motion.button>
          </div>
        )}

        {/* ACTIVE PLAYING ARENA */}
        {gameState === 'PLAYING' && (
          <div className="relative py-4 space-y-5">
            {/* Turn Spotlight Banner */}
            <div className="text-center space-y-1.5">
              <p className="text-xs font-semibold text-purple-700">
                Turn swaps in <span className="font-mono-tabular">{turnCountdown}s</span>
              </p>
              <div
                className={`inline-block px-4 py-2 rounded-xl font-bold text-xs transition-colors ${
                  activeTurn === 1
                    ? 'bg-purple-600 text-white'
                    : 'bg-pink-500 text-white'
                }`}
              >
                {turnBannerText}
              </div>
            </div>

            {/* Two Characters + Animated Score Counters */}
            <div className="relative grid grid-cols-2 gap-3">
              {/* Floating heart & star reaction bursts */}
              <div className="pointer-events-none absolute inset-0 overflow-hidden z-20">
                <AnimatePresence>
                  {bursts.map((b) => (
                    <motion.div
                      key={b.id}
                      initial={{ opacity: 1, y: 20, scale: 0.7 }}
                      animate={{ opacity: 0, y: -52, scale: 1.2 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.6 }}
                      style={{ left: `${b.x}%`, top: `${b.y}%` }}
                      className="absolute flex items-center gap-1 font-bold text-xs"
                    >
                      {b.kind === 'heart' ? (
                        <Heart className="w-4 h-4 text-pink-500 fill-pink-500" />
                      ) : (
                        <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                      )}
                      <span
                        className={
                          b.player === 1 ? 'text-purple-700' : 'text-pink-600'
                        }
                      >
                        {b.label}
                      </span>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              {/* Player 1 Card */}
              <div
                className={`rounded-2xl p-3 border transition-all duration-150 flex flex-col items-center ${
                  activeTurn === 1
                    ? 'bg-white border-purple-400 shadow-[0_10px_24px_-8px_rgba(147,51,234,0.3)] scale-[1.02]'
                    : 'bg-white/60 border-purple-100 opacity-80'
                }`}
              >
                <SisterCharacter
                  player={1}
                  mood={getMood(1)}
                  isActiveTurn={activeTurn === 1}
                  tapPulseKey={p1Pulse}
                />
                <p className="mt-1 text-xs font-semibold text-purple-900">
                  Me (Sister)
                </p>
                <motion.p
                  key={p1Score}
                  initial={{ scale: 1.25 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.12 }}
                  className="font-mono-tabular text-3xl font-bold text-purple-700 mt-0.5"
                >
                  {p1Score}
                </motion.p>
              </div>

              {/* Player 2 Card */}
              <div
                className={`rounded-2xl p-3 border transition-all duration-150 flex flex-col items-center ${
                  activeTurn === 2
                    ? 'bg-white border-pink-400 shadow-[0_10px_24px_-8px_rgba(236,72,153,0.32)] scale-[1.02]'
                    : 'bg-white/60 border-pink-100 opacity-80'
                }`}
              >
                <SisterCharacter
                  player={2}
                  mood={getMood(2)}
                  isActiveTurn={activeTurn === 2}
                  tapPulseKey={p2Pulse}
                />
                <p className="mt-1 text-xs font-semibold text-pink-700">
                  My Sister 👑
                </p>
                <motion.p
                  key={p2Score}
                  initial={{ scale: 1.25 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.12 }}
                  className="font-mono-tabular text-3xl font-bold text-pink-600 mt-0.5"
                >
                  {p2Score}
                </motion.p>
              </div>
            </div>

            {/* Huge Touch-Friendly BEAT Button (zero-delay pointerDown + keyboard) */}
            <div className="pt-1">
              <button
                type="button"
                onPointerDown={(e) => {
                  e.preventDefault();
                  handleBeatTap('human');
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    handleBeatTap('human');
                  }
                }}
                disabled={gameMode === 'vs-bot' && activeTurn === 2}
                style={{ transform: `scale(${beatScale})` }}
                className={`w-full min-h-[120px] rounded-3xl font-bold text-2xl text-white shadow-[0_16px_38px_-8px_rgba(236,72,153,0.55)] transition-transform duration-75 select-none touch-manipulation flex flex-col items-center justify-center gap-1 cursor-pointer ${
                  gameMode === 'vs-bot' && activeTurn === 2
                    ? 'bg-pink-300 cursor-not-allowed'
                    : activeTurn === 1
                    ? 'bg-gradient-to-r from-purple-600 to-fuchsia-600 active:brightness-110'
                    : 'bg-gradient-to-r from-pink-500 to-rose-500 active:brightness-110'
                }`}
              >
                <span>
                  {gameMode === 'vs-bot' && activeTurn === 2
                    ? 'SISTER BOT DANCING! 👑'
                    : 'TAP BEAT! 🎵❤️'}
                </span>
                <span className="text-xs font-medium text-white/90">
                  {activeTurn === 1 ? 'Player 1 Tap Zone' : 'Player 2 Tap Zone'}
                </span>
              </button>
            </div>
          </div>
        )}

        {/* WINNER SCREEN */}
        {gameState === 'FINISHED' && (
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.45 }}
            className="py-5 text-center space-y-5"
          >
            <div className="mx-auto w-14 h-14 rounded-full bg-gradient-to-br from-amber-300 to-pink-500 text-white flex items-center justify-center shadow-lg">
              {p1Won ? <Trophy className="w-7 h-7" /> : <Crown className="w-7 h-7" />}
            </div>

            <h3 className="font-cursive text-3xl text-[#2B1537] [text-wrap:balance]">
              {p1Won
                ? "HAHA! Today I'm the Champion! 😂"
                : 'OMG! Birthday Girl Is The Queen! 👑❤️'}
            </h3>

            {/* Final characters celebration / funny losing face */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white rounded-2xl p-3 border border-purple-200 flex flex-col items-center">
                <SisterCharacter
                  player={1}
                  mood={p1Won ? 'winning' : 'losing'}
                  isActiveTurn={false}
                  tapPulseKey={p1Pulse}
                />
                <p className="text-xs font-semibold text-purple-900 mt-1">Me (Sister)</p>
                <p className="font-mono-tabular text-xl font-bold text-purple-700">
                  {p1Score} pts
                </p>
              </div>

              <div className="bg-white rounded-2xl p-3 border border-pink-200 flex flex-col items-center">
                <SisterCharacter
                  player={2}
                  mood={!p1Won ? 'winning' : 'losing'}
                  isActiveTurn={false}
                  tapPulseKey={p2Pulse}
                />
                <p className="text-xs font-semibold text-pink-700 mt-1">Birthday Girl</p>
                <p className="font-mono-tabular text-xl font-bold text-pink-600">
                  {p2Score} pts
                </p>
              </div>
            </div>

            <p className="font-cursive text-2xl text-pink-600">
              Winner or Loser, You Will Always Be My Favourite Sister! ❤️
            </p>

            <button
              type="button"
              onClick={startGame}
              className="w-full min-h-[50px] inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-pink-500 to-purple-600 text-white font-semibold text-base shadow-md active:opacity-90 transition-opacity cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Play Again</span>
            </button>
          </motion.div>
        )}
      </div>
    </section>
  );
};
