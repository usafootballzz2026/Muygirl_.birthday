import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Heart, RotateCcw, Eye } from 'lucide-react';

interface BirthdayLetterSectionProps {
  revealTrigger: number;
}

const LETTER_LINES = [
  'Happy Birthday, My Dear Sister! ❤️',
  'You are not just my sister, you are a precious part of my life.',
  'No matter how much we fight, my love for you will never change.',
  'You are my childhood memories and my forever happiness.',
  'Thank you for being a beautiful part of my journey.',
  'I may not express my love every day, but you mean the world to me.',
  'I always wish to see you smiling and achieving great things.',
  'May all your dreams come true.',
  'May God bless you with endless happiness and success.',
  'Whenever life gets difficult, remember that I am always there for you.',
  'Distance or situations can never change our bond.',
  'Keep smiling, keep shining, and never lose your beautiful heart.',
  'You deserve all the love and happiness in this world.',
  'I am truly blessed to have you as my sister.',
  'Love you forever and ever, my dear sister! ❤️',
];

export const BirthdayLetterSection: React.FC<BirthdayLetterSectionProps> = ({ revealTrigger }) => {
  const [activeLineIdx, setActiveLineIdx] = useState(0);
  const [charCount, setCharCount] = useState(0);
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    setActiveLineIdx(0);
    setCharCount(0);
    setShowAll(false);
  }, [revealTrigger]);

  useEffect(() => {
    if (showAll) return;
    if (activeLineIdx >= LETTER_LINES.length) return;

    const currentLine = LETTER_LINES[activeLineIdx];
    if (charCount < currentLine.length) {
      const timeout = window.setTimeout(() => {
        setCharCount((c) => c + 1);
      }, 24);
      return () => window.clearTimeout(timeout);
    } else {
      const pauseTimeout = window.setTimeout(() => {
        setActiveLineIdx((idx) => idx + 1);
        setCharCount(0);
      }, 260);
      return () => window.clearTimeout(pauseTimeout);
    }
  }, [activeLineIdx, charCount, showAll]);

  const handleReplay = () => {
    setShowAll(false);
    setActiveLineIdx(0);
    setCharCount(0);
  };

  const isComplete = showAll || activeLineIdx >= LETTER_LINES.length;

  return (
    <section id="letter" className="relative z-10 py-10 px-4">
      <motion.div
        initial={{ opacity: 0, y: 18 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-40px' }}
        transition={{ duration: 0.65 }}
        className="text-center mb-6"
      >
        <p className="text-xs font-medium text-purple-700 mb-2">
          Chapter 02 · Straight From My Heart
        </p>
        <h2 className="font-cursive text-4xl text-[#2B1537] [text-wrap:balance]">
          An Emotional Birthday Letter ❤️
        </h2>
      </motion.div>

      <div className="relative bg-white/95 border border-pink-200/80 rounded-3xl p-5 shadow-[0_20px_50px_-16px_rgba(236,72,153,0.18)]">
        {/* Wax seal emblem + mobile-safe stacked controls */}
        <div className="flex flex-col gap-4 border-b border-pink-100 pb-5 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-full bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center text-white shadow-sm shrink-0">
              <Heart className="w-5 h-5 fill-white" />
            </div>
            <div>
              <p className="font-cursive text-2xl text-[#2B1537] leading-none">
                For My Dearest Sister
              </p>
              <p className="text-xs text-purple-700/75 mt-1">
                Sister to Sister · Forever Bond
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {!isComplete && (
              <button
                type="button"
                onClick={() => setShowAll(true)}
                className="flex-1 min-h-[44px] inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-pink-50 text-pink-700 active:bg-pink-100 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap"
              >
                <Eye className="w-4 h-4" />
                <span>Show Full Letter</span>
              </button>
            )}
            <button
              type="button"
              onClick={handleReplay}
              className="flex-1 min-h-[44px] inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-purple-50 text-purple-800 active:bg-purple-100 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Replay Typing</span>
            </button>
          </div>
        </div>

        <div className="space-y-4 text-[15px] leading-[1.7] text-[#381C47]">
          {LETTER_LINES.map((line, idx) => {
            if (!showAll && idx > activeLineIdx) {
              return null;
            }

            const displayedText =
              showAll || idx < activeLineIdx ? line : line.slice(0, charCount);
            const isCurrentlyTyping = !showAll && idx === activeLineIdx;
            const isSalutationOrClosing = idx === 0 || idx === LETTER_LINES.length - 1;

            return (
              <p
                key={idx}
                className={
                  isSalutationOrClosing
                    ? 'font-cursive text-2xl sm:text-3xl text-pink-600 pt-1 pb-1'
                    : 'text-[#381C47]'
                }
              >
                {displayedText}
                {isCurrentlyTyping && (
                  <span
                    className="inline-block w-0.5 h-5 ml-1 bg-pink-500 align-middle animate-pulse"
                    aria-hidden="true"
                  />
                )}
              </p>
            );
          })}
        </div>
      </div>
    </section>
  );
};
