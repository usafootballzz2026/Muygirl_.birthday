import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Heart,
  ImagePlus,
  X,
  ChevronLeft,
  ChevronRight,
  Trash2,
} from 'lucide-react';
import {
  StoredMemoryPhoto,
  loadUploadedPhotos,
  saveUploadedPhoto,
  deleteUploadedPhoto,
} from '../utils/photoStorage';

const INITIAL_MEMORIES: StoredMemoryPhoto[] = [
  {
    id: 'childhood-1',
    src: '/assets/memories/childhood_sisters.jpg',
    caption: 'Our Childhood, Our Memories, Our Forever Bond.',
    subtitle: 'Little Us · Childhood Treasure',
    category: 'childhood',
    createdAt: 1,
  },
  {
    id: 'together-4',
    src: '/assets/memories/memory_4.jpg',
    caption: 'Unstoppable laughter that only sisters understand.',
    subtitle: 'Golden Hour Laughs · Sister Moments',
    category: 'together',
    createdAt: 2,
  },
  {
    id: 'together-6',
    src: '/assets/memories/memory_6.jpg',
    caption: 'Walking side by side through every season of life.',
    subtitle: 'Side By Side · Forever Bond',
    category: 'together',
    createdAt: 3,
  },
  {
    id: 'together-2',
    src: '/assets/memories/memory_2.jpg',
    caption: 'Twinning smiles and endless sister inside jokes.',
    subtitle: 'Twinning Moments · Sister Love',
    category: 'together',
    createdAt: 4,
  },
  {
    id: 'together-1',
    src: '/assets/memories/memory_1.jpg',
    caption: 'Your warm smile lights up every single celebration.',
    subtitle: 'Birthday Queen · Joyful Grace',
    category: 'together',
    createdAt: 5,
  },
  {
    id: 'together-3',
    src: '/assets/memories/memory_3.jpg',
    caption: 'No matter how much we grow, we are always each other’s home.',
    subtitle: 'Sweet Memories · Together Always',
    category: 'together',
    createdAt: 6,
  },
  {
    id: 'together-5',
    src: '/assets/memories/memory_5.jpg',
    caption: 'Silly selfies, shared secrets, and pure sister magic.',
    subtitle: 'Playful Days · Pure Joy',
    category: 'together',
    createdAt: 7,
  },
  {
    id: 'together-7',
    src: '/assets/memories/sisters_together.jpg',
    caption: 'Two hearts, one lifelong story of love and strength.',
    subtitle: 'Forever Sisters · Always Connected',
    category: 'together',
    createdAt: 8,
  },
];

export const MemoriesGallerySection: React.FC = () => {
  const [uploadedPhotos, setUploadedPhotos] = useState<StoredMemoryPhoto[]>([]);
  const [filter, setFilter] = useState<'all' | 'childhood' | 'together'>('all');
  const [likedIds, setLikedIds] = useState<Record<string, boolean>>({
    'childhood-1': true,
    'together-4': true,
  });
  const [floatingHeartId, setFloatingHeartId] = useState<string | null>(null);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [brokenIds, setBrokenIds] = useState<Record<string, boolean>>({});
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    loadUploadedPhotos().then((items) => {
      if (items.length > 0) {
        setUploadedPhotos(items);
      }
    });
  }, []);

  const allPhotos = [...uploadedPhotos, ...INITIAL_MEMORIES];
  const filteredPhotos = allPhotos.filter((photo) => {
    if (filter === 'all') return true;
    return photo.category === filter;
  });

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (lightboxIndex === null) return;
      if (e.key === 'Escape') {
        setLightboxIndex(null);
      } else if (e.key === 'ArrowRight') {
        setLightboxIndex((prev) =>
          prev === null ? null : (prev + 1) % filteredPhotos.length
        );
      } else if (e.key === 'ArrowLeft') {
        setLightboxIndex((prev) =>
          prev === null
            ? null
            : (prev - 1 + filteredPhotos.length) % filteredPhotos.length
        );
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [lightboxIndex, filteredPhotos.length]);

  const handleToggleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setLikedIds((prev) => ({ ...prev, [id]: !prev[id] }));
    setFloatingHeartId(id);
    window.setTimeout(() => {
      setFloatingHeartId((curr) => (curr === id ? null : curr));
    }, 650);
  };

  const handleUploadFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = async () => {
        const result = typeof reader.result === 'string' ? reader.result : '';
        if (!result) return;
        const newPhoto: StoredMemoryPhoto = {
          id: `uploaded-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          src: result,
          caption: 'Our Childhood, Our Memories, Our Forever Bond.',
          subtitle: 'Uploaded Memory · Forever Bond',
          category: filter === 'childhood' ? 'childhood' : 'together',
          createdAt: Date.now(),
          isUploaded: true,
        };
        setUploadedPhotos((prev) => [newPhoto, ...prev]);
        await saveUploadedPhoto(newPhoto);
      };
      reader.readAsDataURL(file);
    });

    e.target.value = '';
  };

  const handleRemoveUploaded = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setUploadedPhotos((prev) => prev.filter((p) => p.id !== id));
    await deleteUploadedPhoto(id);
    setLightboxIndex(null);
  };

  const childhoodSpotlight = allPhotos.find((p) => p.category === 'childhood');

  return (
    <section id="memories" className="relative z-10 py-10 px-4">
      {/* Header + Mobile-friendly Filter & Upload toolbar */}
      <div className="space-y-4 mb-7">
        <div className="text-center">
          <p className="text-xs font-medium text-purple-700 mb-1.5">
            Chapter 03 · Our Childhood, Our Memories, Our Forever Bond
          </p>
          <h2 className="font-cursive text-4xl text-[#2B1537] [text-wrap:balance]">
            Beautiful Memories Gallery
          </h2>
        </div>

        <div className="flex flex-col gap-3">
          <div className="grid grid-cols-3 gap-1 p-1 bg-purple-100/70 rounded-2xl border border-purple-200/70">
            <button
              type="button"
              onClick={() => setFilter('all')}
              className={`min-h-[44px] px-2 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                filter === 'all'
                  ? 'bg-white text-[#2B1537] shadow-sm'
                  : 'text-purple-800'
              }`}
            >
              All
            </button>
            <button
              type="button"
              onClick={() => setFilter('childhood')}
              className={`min-h-[44px] px-2 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                filter === 'childhood'
                  ? 'bg-white text-[#2B1537] shadow-sm'
                  : 'text-purple-800'
              }`}
            >
              Childhood
            </button>
            <button
              type="button"
              onClick={() => setFilter('together')}
              className={`min-h-[44px] px-2 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                filter === 'together'
                  ? 'bg-white text-[#2B1537] shadow-sm'
                  : 'text-purple-800'
              }`}
            >
              Together
            </button>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            onChange={handleUploadFiles}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="w-full min-h-[46px] inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-pink-500 to-purple-600 text-white text-sm font-semibold shadow-sm active:opacity-90 transition-opacity cursor-pointer"
          >
            <ImagePlus className="w-4 h-4" />
            <span>Add Photos From Phone</span>
          </button>
        </div>
      </div>

      {/* Featured Childhood Memory Highlight */}
      {childhoodSpotlight && filter !== 'together' && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.6 }}
          onClick={() => {
            const idx = filteredPhotos.findIndex((p) => p.id === childhoodSpotlight.id);
            if (idx >= 0) setLightboxIndex(idx);
          }}
          className="mb-6 flex flex-col gap-4 bg-white/95 border border-pink-200/80 rounded-3xl p-4 shadow-[0_16px_40px_-14px_rgba(168,85,247,0.16)] cursor-pointer"
        >
          <div className="overflow-hidden rounded-2xl bg-pink-50 aspect-[4/5] max-h-[340px] w-full flex items-center justify-center">
            {brokenIds[childhoodSpotlight.id] ? (
              <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-pink-100 to-purple-100">
                <Heart className="w-10 h-10 text-pink-500 mb-2" />
                <p className="text-sm font-medium text-purple-900">
                  {childhoodSpotlight.subtitle}
                </p>
              </div>
            ) : (
              <img
                src={childhoodSpotlight.src}
                alt={childhoodSpotlight.caption}
                referrerPolicy="no-referrer"
                onError={() =>
                  setBrokenIds((prev) => ({ ...prev, [childhoodSpotlight.id]: true }))
                }
                className="w-full h-full object-cover"
              />
            )}
          </div>

          <div className="space-y-3 px-1 pb-1">
            <p className="text-xs font-medium text-pink-600">
              Childhood Spotlight · Precious Beginning
            </p>
            <h3 className="font-cursive text-3xl text-[#2B1537] leading-snug">
              &ldquo;Our Childhood, Our Memories, Our Forever Bond.&rdquo;
            </h3>
            <p className="text-[15px] text-[#5B3D6B] leading-relaxed">
              Before we knew how fast time would fly, we already had each other’s hands held tight. No matter how tall we grow, you will always be my tiny little sister in my heart.
            </p>
            <div className="pt-1 flex items-center justify-between text-xs text-purple-800/80">
              <span>Tap photo to enlarge</span>
              <button
                type="button"
                onClick={(e) => handleToggleLike(childhoodSpotlight.id, e)}
                className="min-h-[44px] inline-flex items-center gap-1.5 px-3 rounded-xl font-semibold text-pink-600 active:bg-pink-50 cursor-pointer"
              >
                <Heart
                  className={`w-4 h-4 ${
                    likedIds[childhoodSpotlight.id] ? 'fill-pink-500 text-pink-500' : ''
                  }`}
                />
                <span>{likedIds[childhoodSpotlight.id] ? 'Loved' : 'Love Memory'}</span>
              </button>
            </div>
          </div>
        </motion.div>
      )}

      {/* Single-Column Mobile Photo Cards */}
      <div className="grid grid-cols-1 gap-5">
        {filteredPhotos.map((photo, index) => {
          const isLiked = !!likedIds[photo.id];
          const showFloating = floatingHeartId === photo.id;

          return (
            <motion.article
              key={photo.id}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ duration: 0.5, delay: Math.min(index * 0.05, 0.25) }}
              onClick={() => setLightboxIndex(index)}
              className="relative group bg-white border border-pink-100 rounded-2xl overflow-hidden shadow-[0_12px_32px_-12px_rgba(147,51,234,0.14)] hover:shadow-[0_20px_44px_-12px_rgba(236,72,153,0.24)] transition-all duration-300 cursor-pointer flex flex-col"
            >
              <div className="relative aspect-[4/3] w-full overflow-hidden bg-gradient-to-br from-pink-50 to-purple-50">
                {brokenIds[photo.id] ? (
                  <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center">
                    <Heart className="w-8 h-8 text-pink-400 mb-2" />
                    <span className="text-xs font-medium text-purple-800">
                      {photo.subtitle}
                    </span>
                  </div>
                ) : (
                  <img
                    src={photo.src}
                    alt={photo.caption}
                    referrerPolicy="no-referrer"
                    onError={() =>
                      setBrokenIds((prev) => ({ ...prev, [photo.id]: true }))
                    }
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                  />
                )}

                {/* Subtle bottom gradient for clean hover affordance */}
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                {/* Floating animated heart reaction burst */}
                <AnimatePresence>
                  {showFloating && (
                    <motion.div
                      initial={{ opacity: 1, y: 0, scale: 0.7 }}
                      animate={{ opacity: 0, y: -48, scale: 1.45 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.6 }}
                      className="pointer-events-none absolute bottom-4 right-4 z-20"
                    >
                      <Heart className="w-8 h-8 text-pink-500 fill-pink-500" />
                    </motion.div>
                  )}
                </AnimatePresence>

                <button
                  type="button"
                  onClick={(e) => handleToggleLike(photo.id, e)}
                  aria-label="Love this memory"
                  className="absolute top-3 right-3 w-10 h-10 rounded-full bg-white/90 backdrop-blur-sm text-pink-600 flex items-center justify-center shadow-sm hover:scale-105 transition-transform cursor-pointer"
                >
                  <Heart
                    className={`w-4 h-4 ${isLiked ? 'fill-pink-500 text-pink-500' : ''}`}
                  />
                </button>

                {photo.isUploaded && (
                  <button
                    type="button"
                    onClick={(e) => handleRemoveUploaded(photo.id, e)}
                    aria-label="Remove uploaded photo"
                    className="absolute top-3 left-3 w-10 h-10 rounded-full bg-white/90 backdrop-blur-sm text-purple-800 hover:text-rose-600 flex items-center justify-center shadow-sm transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between gap-2">
                <p className="text-xs font-medium text-purple-700/80">
                  {photo.subtitle}
                </p>
                <p className="text-sm sm:text-[15px] font-medium text-[#2B1537] leading-snug">
                  {photo.caption}
                </p>
              </div>
            </motion.article>
          );
        })}
      </div>

      {/* Fullscreen Lightbox Viewer */}
      <AnimatePresence>
        {lightboxIndex !== null && filteredPhotos[lightboxIndex] && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-[#14071D]/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-8"
            onClick={() => setLightboxIndex(null)}
          >
            <div
              className="relative max-w-3xl w-full bg-[#1F0E2B] border border-pink-300/25 rounded-3xl overflow-hidden shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                type="button"
                onClick={() => setLightboxIndex(null)}
                aria-label="Close photo viewer"
                className="absolute top-4 right-4 z-20 w-11 h-11 rounded-full bg-black/60 text-white hover:bg-black/80 flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="relative flex items-center justify-center bg-black/50 min-h-[320px] max-h-[70vh]">
                <img
                  src={filteredPhotos[lightboxIndex].src}
                  alt={filteredPhotos[lightboxIndex].caption}
                  referrerPolicy="no-referrer"
                  className="max-h-[70vh] w-auto object-contain"
                />

                {filteredPhotos.length > 1 && (
                  <>
                    <button
                      type="button"
                      onClick={() =>
                        setLightboxIndex(
                          (lightboxIndex - 1 + filteredPhotos.length) %
                            filteredPhotos.length
                        )
                      }
                      aria-label="Previous memory"
                      className="absolute left-3 w-11 h-11 rounded-full bg-black/55 text-white hover:bg-black/80 flex items-center justify-center transition-colors cursor-pointer"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setLightboxIndex(
                          (lightboxIndex + 1) % filteredPhotos.length
                        )
                      }
                      aria-label="Next memory"
                      className="absolute right-3 w-11 h-11 rounded-full bg-black/55 text-white hover:bg-black/80 flex items-center justify-center transition-colors cursor-pointer"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </>
                )}
              </div>

              <div className="p-6 bg-gradient-to-t from-[#190924] to-[#261136] text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <p className="text-xs text-pink-300 font-medium">
                    {filteredPhotos[lightboxIndex].subtitle}
                  </p>
                  <p className="mt-1 text-base sm:text-lg font-medium text-white">
                    {filteredPhotos[lightboxIndex].caption}
                  </p>
                </div>
                <span className="font-mono-tabular text-xs text-purple-200 shrink-0">
                  {lightboxIndex + 1} / {filteredPhotos.length}
                </span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};
