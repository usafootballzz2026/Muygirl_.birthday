import React, { useRef, useState } from 'react';
import { motion } from 'motion/react';
import { Play, Pause, Volume2, VolumeX, Heart, ArrowDown } from 'lucide-react';

interface BirthdayVideoSectionProps {
  onVideoEnded: () => void;
  onPlaybackChange?: (playing: boolean) => void;
}

const VIDEO_SRC = '/assets/aistudio/VID-20261115-WA0000_60900e45.mp4';

export const BirthdayVideoSection: React.FC<BirthdayVideoSectionProps> = ({
  onVideoEnded,
  onPlaybackChange,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [hasStarted, setHasStarted] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(14.9);
  const [videoEndedOnce, setVideoEndedOnce] = useState(false);

  const handlePlayClick = () => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = isMuted;
    if (video.paused || video.ended) {
      if (video.ended) {
        video.currentTime = 0;
      }
      video.play().catch(() => {});
      setHasStarted(true);
      setIsPlaying(true);
    } else {
      video.pause();
      setIsPlaying(false);
    }
  };

  const handleToggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    const nextMuted = !isMuted;
    video.muted = nextMuted;
    setIsMuted(nextMuted);
  };

  const handleTimeUpdate = () => {
    const video = videoRef.current;
    if (!video) return;
    const dur = video.duration || 14.9;
    setDuration(dur);
    setCurrentTime(video.currentTime);
    setProgress((video.currentTime / dur) * 100);
  };

  const handleEnded = () => {
    setIsPlaying(false);
    onPlaybackChange?.(false);
    setProgress(100);
    setVideoEndedOnce(true);
    setTimeout(() => {
      onVideoEnded();
    }, 650);
  };

  return (
    <section id="video" className="relative z-10 py-10 px-4">
      <div className="flex flex-col items-center gap-6">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.65 }}
          className="space-y-3 text-center"
        >
          <p className="text-xs font-medium text-purple-700">
            Chapter 01 · 14 Seconds of Pure Love
          </p>

          <h2 className="font-cursive text-4xl text-[#2B1537] leading-tight [text-wrap:balance]">
            Our Memories In Motion
          </h2>

          <p className="text-[15px] text-[#5B3D6B] leading-relaxed">
            Turn up your volume and press play on your special 14-second birthday reel.
          </p>
        </motion.div>

        {/* Mobile-fit vertical 9:16 video frame preserving exact aspect ratio & quality */}
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.7 }}
          className="w-full flex justify-center"
        >
          <div className="relative w-full max-w-[300px]">
            {/* Glowing pink & lavender aura */}
            <div
              className="pointer-events-none absolute -inset-3 rounded-[2.2rem] bg-gradient-to-tr from-pink-400/35 via-fuchsia-300/30 to-purple-400/35 blur-xl"
              aria-hidden="true"
            />

            {/* Floating corner hearts */}
            <Heart
              className="pointer-events-none absolute -top-4 -right-2 w-7 h-7 text-pink-500 fill-pink-400/80 animate-float-slow z-20"
              aria-hidden="true"
            />
            <Heart
              className="pointer-events-none absolute -bottom-3 -left-2 w-6 h-6 text-purple-500 fill-purple-400/80 animate-float-slow z-20"
              style={{ animationDelay: '1.2s' }}
              aria-hidden="true"
            />

            <div className="relative rounded-[1.8rem] p-2 bg-gradient-to-b from-pink-200 via-white to-purple-200 shadow-[0_20px_50px_-14px_rgba(147,51,234,0.28)] border border-white">
              <div className="relative aspect-[9/16] max-h-[66dvh] w-full overflow-hidden rounded-[1.35rem] bg-[#160B1E]">
                <video
                  ref={videoRef}
                  src={VIDEO_SRC}
                  playsInline
                  preload="auto"
                  controls={hasStarted}
                  onTimeUpdate={handleTimeUpdate}
                  onPlay={() => {
                    setHasStarted(true);
                    setIsPlaying(true);
                    onPlaybackChange?.(true);
                  }}
                  onPause={() => {
                    setIsPlaying(false);
                    onPlaybackChange?.(false);
                  }}
                  onEnded={handleEnded}
                  className="w-full h-full object-contain bg-black"
                />

                {/* Elegant Play Overlay before video starts */}
                {!hasStarted && (
                  <div
                    onClick={handlePlayClick}
                    className="absolute inset-0 bg-gradient-to-t from-[#1E0B2B]/80 via-[#1E0B2B]/25 to-transparent flex flex-col items-center justify-center p-5 cursor-pointer group"
                  >
                    <div className="w-20 h-20 rounded-full bg-white/95 text-pink-600 flex items-center justify-center shadow-[0_0_30px_rgba(236,72,153,0.65)] active:scale-95 transition-transform duration-150">
                      <Play className="w-9 h-9 fill-pink-600 ml-1" />
                    </div>
                    <p className="mt-4 font-cursive text-3xl text-white drop-shadow text-center">
                      Tap To Play Surprise
                    </p>
                    <p className="mt-1 text-xs font-medium text-pink-100">
                      14 Seconds · Sound On
                    </p>
                  </div>
                )}
              </div>

              {/* Finger-friendly 44px playback bar */}
              <div className="mt-2 px-1 pb-0.5 flex items-center justify-between gap-2.5">
                <button
                  type="button"
                  onClick={handlePlayClick}
                  aria-label={isPlaying ? 'Pause video' : 'Play video'}
                  className="w-11 h-11 rounded-full bg-pink-50 text-pink-600 active:bg-pink-100 flex items-center justify-center transition-colors cursor-pointer shrink-0"
                >
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-pink-600 ml-0.5" />}
                </button>

                <div className="flex-1">
                  <div className="h-2 w-full rounded-full bg-purple-100 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-pink-500 to-purple-600 transition-all duration-150"
                      style={{ width: `${Math.min(100, progress)}%` }}
                    />
                  </div>
                </div>

                <span className="font-mono-tabular text-xs text-purple-800 shrink-0">
                  {Math.floor(currentTime)}s / {Math.round(duration)}s
                </span>

                <button
                  type="button"
                  onClick={handleToggleMute}
                  aria-label={isMuted ? 'Unmute video' : 'Mute video'}
                  className="w-11 h-11 rounded-full bg-purple-50 text-purple-700 active:bg-purple-100 flex items-center justify-center transition-colors cursor-pointer shrink-0"
                >
                  {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                </button>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Full-width mobile action buttons */}
        <div className="w-full space-y-3 pt-1">
          <button
            type="button"
            onClick={handlePlayClick}
            className="w-full min-h-[48px] inline-flex items-center justify-center gap-2.5 px-6 py-3 rounded-2xl bg-gradient-to-r from-pink-500 to-purple-600 text-white font-semibold text-base shadow-[0_10px_24px_-6px_rgba(236,72,153,0.45)] active:opacity-90 transition-opacity cursor-pointer"
          >
            {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-white" />}
            <span>{isPlaying ? 'Pause Video' : hasStarted ? 'Resume Video' : 'Play Birthday Video'}</span>
          </button>

          <button
            type="button"
            onClick={onVideoEnded}
            className="w-full min-h-[48px] inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-white border border-purple-200 text-purple-800 font-semibold text-sm active:bg-purple-50 transition-colors cursor-pointer"
          >
            <span>Read Birthday Letter</span>
            <ArrowDown className="w-4 h-4" />
          </button>

          {videoEndedOnce && (
            <p className="text-center text-sm font-medium text-pink-600 pt-1">
              Your birthday letter awaits right below ❤️
            </p>
          )}
        </div>
      </div>
    </section>
  );
};
